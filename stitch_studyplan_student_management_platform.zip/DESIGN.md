---
name: Scholarly Agenda & Academic Planner
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#47464f'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#787680'
  outline-variant: '#c8c5d0'
  surface-tint: '#5b598c'
  primary: '#070235'
  on-primary: '#ffffff'
  primary-container: '#1e1b4b'
  on-primary-container: '#8683ba'
  inverse-primary: '#c4c1fb'
  secondary: '#006b5f'
  on-secondary: '#ffffff'
  secondary-container: '#6df5e1'
  on-secondary-container: '#006f64'
  tertiary: '#000a22'
  on-tertiary: '#ffffff'
  tertiary-container: '#00204d'
  on-tertiary-container: '#4086fa'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3dfff'
  primary-fixed-dim: '#c4c1fb'
  on-primary-fixed: '#181445'
  on-primary-fixed-variant: '#444173'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 3.5rem
    fontWeight: '400'
    lineHeight: 4rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 2.25rem
    fontWeight: '400'
    lineHeight: 2.75rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 2rem
    fontWeight: '500'
    lineHeight: 2.5rem
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 1.625rem
    fontWeight: '500'
    lineHeight: 2.125rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
  headline-sm:
    fontFamily: Newsreader
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes an elite scholarly agenda for higher education. It bridges the rigorous academic journey of university students with the reassuring transparency required by involved parents. By fusing traditional literary distinction with modern, ergonomic interaction patterns, the interface balances intellectual depth, focused clarity, and calm encouragement.

The aesthetic marries classic editorial craft with contemporary utilitarian precision:
- **Literary Sophistication:** Evokes leather-bound notebooks, academic journals, and university library archives through graceful serif titles that confer gravitas onto everyday study goals.
- **Calm, High-Focus Workspace:** Generous whitespace, disciplined contrast, and structured neutral surfaces mitigate cognitive fatigue during dense exam preparations and assignment tracking.
- **Supportive Partnership:** Dedicated signifiers—such as clear "Chỉ xem" (Read-only) observer credentials for parents—create a culture of trust and shared progress without crowding the student's personal agency.

## Colors

The color palette centers on midnight ink tones paired with targeted intellectual accents and clear operational indicators.

### Key Tokens & Functional Roles
- **Primary (`#1E1B4B` - Midnight Navy):** Imparts weight, institutional focus, and scholarly dignity. Used for critical navigational structures, key headers, active states, and dominant interactive buttons.
- **Secondary (`#14B8A6` - Focused Teal):** Drives academic progression markers, milestone accomplishments, and deliberate calls to action.
- **Tertiary (`#3B82F6` - Intellectual Blue):** Reserved for in-progress tasks, study session indicators, and active course badges.
- **Neutral (`#0F172A` - Slate Charcoal):** Serves as deep primary typography and high-emphasis structure on clean background fields (`#F8FAFC`).

### Academic Lifecycle Indicators
Status tokens map directly to the cadence of university deadlines and deliver unambiguous semantic meaning:
- **Chưa bắt đầu (Not Started):** `#64748B` (Neutral Slate) – Passive, secondary state.
- **Đang làm (In Progress):** `#3B82F6` (Electric Azure) – Active, dynamic engagement.
- **Hoàn thành (Completed):** `#10B981` (Emerald) – Validated achievement.
- **Sắp đến hạn (Due Soon):** `#F59E0B` (Amber) – Urgent advisory.
- **Quá hạn (Overdue):** `#EF4444` (Crimson) – Immediate corrective priority.

### Dark Mode Adaptations
When rendering in dark mode, the ground shifts to `#0B0F19`, containers rest at `#131B2E`, borders soften into `#1E293B`, and primary text rises to `#F1F5F9`, maintaining pristine contrast ratios across all Vietnamese diacritics.

## Typography

Typography establishes an intentional dichotomy:
- **Newsreader (Display & Headlines):** Channels the authoritative voice of literary scholarship. Used for dashboard greetings, course titles, module milestones, and study phase transitions. It exhibits generous vertical space to gracefully accommodate Vietnamese tone markers (`dấu hỏi`, `dấu ngã`, `dấu nặng`) without line collision.
- **Plus Jakarta Sans (Body, Functional Labels & Data):** A geometric yet friendly sans-serif offering unmatched readability across dense scheduling tables, syllabus checklists, and grade calculation inputs.

### Typographic Rules
- Vietnamese text metrics demand a strict minimum `1.5` line-height on all body copies to avoid vertical clipping of stacked accents.
- Display serifs should remain in optical standard or italic for personal study reflection prompts, never exceeding weight `600`.

## Layout & Spacing

The layout is built upon an 8px rhythmic grid engineered for deep desktop planning sessions and rapid mobile schedule lookups.

### Form Factor Behavior
- **Desktop (≥ 1024px):** Fixed navigation sidebar (260px) alongside a dynamic 12-column layout. The outer margin stays at `2rem` (`space-xl`), while gutters remain `1.5rem` (`gutter`). Complex multi-week calendars and task matrices expand horizontally without crowding.
- **Tablet (768px - 1023px):** Collapsible slim sidebar icon rail (72px) with an 8-column workspace.
- **Mobile (< 768px):** The structural rail transitions to an anchored bottom navigation bar (64px height) with safe-area hardware padding. Content condenses into a clean 4-column flow with `1rem` (`margin-mobile`) boundaries and `1rem` gutters.

## Elevation & Depth

Visual hierarchy relies on structural tonal separation rather than heavy skeuomorphism, reflecting a clean and modern academic surface.

### Elevation Hierarchy
- **Level 0 (Canvas Base):** Light `#F8FAFC` foundation. Non-elevated, clean paper ground.
- **Level 1 (Card & Section Containers):** Pure `#FFFFFF` fill bounded by a crisp 1px stroke in `#E2E8F0`. Shadow is microscopic and tinted: `0 1px 3px rgba(15, 23, 42, 0.04), 0 1px 2px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Active Modules & Focused Cards):** Rises slightly to indicate current activity or hovering assignment rows: `0 4px 6px -1px rgba(30, 27, 75, 0.06), 0 2px 4px -2px rgba(30, 27, 75, 0.04)`.
- **Level 3 (Modals & Command Sheets):** Floats above the workspace with an indigo-tinted drop shadow: `0 20px 25px -5px rgba(30, 27, 75, 0.1), 0 8px 10px -6px rgba(30, 27, 75, 0.06)`.

## Shapes

The design system maintains a balanced rounded geometry (Level 2), grounding the workspace with friendly yet structured forms:

- **Base Radius (`0.5rem` / 8px):** Form fields, input controls, action chips, and nested sub-tasks.
- **Interactive Buttons & Badges (`0.625rem` - `0.75rem` / 10px–12px):** Secondary touchpoints and primary interactive triggers.
- **Main Structural Cards (`1rem` / 16px):** Course overview modules, study timeline summaries, and analytical cards.
- **Pills (`9999px`):** Reserved exclusively for status indicators, priority tags, and the prominent "Chỉ xem" (Read-only) observer badges.

## Components

### Buttons
- **Primary:** Deep midnight navy background (`#1E1B4B`), white text (`#FFFFFF`), `10px` border-radius, font weight `600`. Hover state lightens to `#2E2A72` with subtle `Level 2` elevation lift.
- **Secondary / Subtle:** Surface `#F1F5F9`, text `#1E1B4B`, border-free for swift operational interactions.
- **Accent:** Background `#14B8A6`, text `#FFFFFF`, used for "Bắt đầu học" (Start Study Session) or "Hoàn tất kế hoạch" (Finalize Plan).

### Cards & Module Containers
- Outlined with `#E2E8F0` at `16px` border-radius (`rounded-lg`). Top-level course headers incorporate Newsreader serif titles paired with status badges pinned to the upper right corner.

### Chips & Badges
- **Status Chips:** Rendered in low-saturation tint backgrounds (10% tint of the status color) with high-contrast text matching the core status token.
- **Observer Badge ("Chỉ xem" / Read-only):** Designed with an unmistakable neutral pill shape: `#F1F5F9` background, `#475569` text, paired with a small subtle eye icon to immediately signal non-editable visibility to parents.

### Form Inputs & Checkboxes
- **Input Fields:** Pure white background, `10px` radius, bordered in `#CBD5E1`. On focus, transitions cleanly to a 1.5px stroke of `#1E1B4B` with an ambient indigo ring (`rgba(30, 27, 75, 0.1)`).
- **Checkboxes:** Smooth `6px` radius checkboxes for study task completion. Checking activates an animated fill of `#10B981` (Completed green) with a clean white vector checkmark.

### Navigation Elements
- **Desktop Sidebar:** Clean left rail featuring an intellectual header, structured study phase links, and a dedicated profile card toggling between "Sinh viên" (Student) and "Phụ huynh" (Parent) modes.
- **Mobile Bottom Bar:** 64px white docking surface with five high-priority touch targets: Lịch học (Calendar), Kế hoạch (Plan), Tiến độ (Progress), Điểm số (Grades), and Hồ sơ (Profile).